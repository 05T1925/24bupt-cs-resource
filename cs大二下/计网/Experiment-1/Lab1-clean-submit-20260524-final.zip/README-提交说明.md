# 计算机网络实验一提交说明

## 目录结构
- `src/`: 仅包含需要提交的自行源文件 `datalink.c`、`datalink.h`。
- `docs/`: 封面、实验报告正文、性能测试记录表、验收评分项对照表、源程序清单。
- `evidence/`: SR 与 GBN 的 1200 秒五组性能测试 summary CSV。

## 运行方式
- 默认运行 SR: `datalink.exe -t 1200 -f A/B`
- 运行 GBN: `datalink.exe --gbn -t 1200 -f A/B`
- 高误码洪泛测试示例: `datalink.exe --gbn --flood --ber=1e-4 -t 1200 A/B`

## 测试证据
- SR: `evidence/SR_summary_1200s.csv`，1200 秒五组测试，全部 Quit=True，FatalMatches=0。
- GBN: `evidence/GBN_summary_1200s.csv`，1200 秒五组测试，最终采纳行均 Quit=True，FatalMatches=0。
- GBN 的 BER=1e-4 flood 第五组已严格重跑，并通过自动验收脚本筛选到 A/B 两端最后统计均接近 1200s 的 attempt-02 样本：A=29.46%，B=26.23%。

## 提交清理
最终 ZIP 仅包含 10 个正式提交文件：`README-提交说明.md`、2 个源文件、5 个 Word 文档、2 个 summary CSV。不提交 `.exe`、`.obj`、`.log`、`.vs`、旧测试目录、脚本或渲染临时目录。
